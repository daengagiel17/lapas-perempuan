<?php $__env->startSection('css'); ?>
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <?php $__env->startComponent('components.wrapper', ['title' => "Placement Test"]); ?>
      <li class="breadcrumb-item active">Placement Test</li>
    <?php echo $__env->renderComponent(); ?>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <?php $__env->startComponent('components.filter', ["fakultas" => $fakultas, "id" => 'placement-test.store']); ?>
            <?php echo $__env->renderComponent(); ?>
          </div>
          <div class="col-12">
            <?php $__env->startComponent('components.table', ['id' => 'data-mahasiswa']); ?>
              <?php $__env->slot('title'); ?>
                List of Nilai Placement Test
              <?php $__env->endSlot(); ?>
              <th>#</th>
              <th>NIM</th>
              <th>Name</th>
              <th>Fakultas / Jurusan</th>
              <th>Nilai</th>
              <th>Action</th>
            <?php echo $__env->renderComponent(); ?>
          </div>
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- DataTables -->
<script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
<!-- page script -->
<script type="text/javascript" language="javascript">
  $(function (){

    load_data();

    function load_data(fakultas = '', jurusan = '', kelas = '')
    {
      $("#data-mahasiswa").DataTable({
        // "processing": true,
        "serverSide": true,
        "ajax": {
          url : "<?php echo e(route('placement-test.index')); ?>",
          data : {
            fakultas: fakultas,
            jurusan: jurusan,
            kelas: kelas
          }
        },
        "columns": [
          {
            data: 'DT_RowIndex',
            name: 'id'
          },
          {
            data: "nim" ,
            name: "nim"
          },
          {
            data: "name",
            name: "name"
          },
          {
            data: "jurusan",
            name: "jurusan"
          },
          {
            data: "nilai_placement",
            name: "nilai_placement" 
          },
          {
            data: "action",
            name: "action"
          }
        ],
      });
    }

    $('#filter').click(function() {
      var fakultas = $('#fakultas').val();
      var jurusan = $('#jurusan').val();
      var kelas = $('#kelas').val();

      $('#data-mahasiswa').DataTable().destroy();
      load_data(fakultas, jurusan, kelas);
    });
    
    $('#reset-filter').click(function() {
      $('#fakultas').empty();
      $('#fakultas').append("<option value=''>Select Fakultas</option>");

      var fakultas = <?php echo json_encode($fakultas); ?>;
      
      for (i = 0; i < fakultas.length; i++)
      {
          $('#fakultas').append("<option value='" + fakultas[i].id + "'>" + fakultas[i].slug + "</option>");
      }

      $('#jurusan').empty();       
      $('#jurusan').append("<option value=''>Select Jurusan</option>");
      $('#kelas').empty();       
      $('#kelas').append("<option value=''>Select Kelas</option>");
    
      $('#data-mahasiswa').DataTable().destroy();
      load_data();

    });


    // When an option is changed, search the above for matching choices
    $('#fakultas').on('change', function() {
      // Set selected option as variable
      var fakultas_id = $(this).val();

      if(fakultas_id)
      {
        // Empty the target field
        $('#jurusan').empty();
        $('#jurusan').append("<option value=''>Select Jurusan</option>");
        $('#kelas').empty();        
        $('#kelas').append("<option value=''>Select Kelas</option>");

        var jurusan = <?php echo json_encode($jurusans); ?>;
        // For each chocie in the selected option
        for (i = 0; i < jurusan[fakultas_id].length; i++)
        {
            $('#jurusan').append("<option value='" + jurusan[fakultas_id][i].id + "'>" + jurusan[fakultas_id][i].slug + "</option>");
        }

      }
      else
      {
        $('#jurusan').empty();        
        $('#jurusan').append("<option value=''>Select Jurusan</option>");
        $('#kelas').empty();        
        $('#kelas').append("<option value=''>Select Kelas</option>");
      }      
    });    

    // When an option is changed, search the above for matching choices
    $('#jurusan').on('change', function() {
      // Set selected option as variable
      var jurusans_id = $(this).val();

      if(jurusans_id)
      {
        // Empty the target field
        $('#kelas').empty();       
        $('#kelas').append("<option value=''>Select Kelas</option>");

        var kelas = <?php echo json_encode($kelas); ?>;
        // For each chocie in the selected option
        for (i = 0; i < kelas[jurusans_id].length; i++)
        {
            $('#kelas').append("<option value='" + kelas[jurusans_id][i].id + "'>" + kelas[jurusans_id][i].name + "</option>");
        }

      }
      else
      {
        $('#kelas').empty();        
        $('#kelas').append("<option value=''>Select Kelas</option>");
      }      
    });    

  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/daeng_agiel/Development/Laravel/admin_slq/resources/views/placement-test/index.blade.php ENDPATH**/ ?>