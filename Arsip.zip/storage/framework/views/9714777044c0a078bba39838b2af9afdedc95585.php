<?php $__env->startSection('css'); ?>
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <?php $__env->startComponent('components.wrapper', ['title' => "Surat"]); ?>
      <li class="breadcrumb-item active">Surat</li>
    <?php echo $__env->renderComponent(); ?>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          
          <div class="col-12">
            <?php $__env->startComponent('components.table', ['id' => 'data-mahasiswa']); ?>
              <?php $__env->slot('title'); ?>
                List of Surat
              <?php $__env->endSlot(); ?>
              <th>#</th>
              <th>No Register</th>
              <th>Nama</th>
              <th>Surat RT/RW Dibuat</th>
              <th>Surat RT/RW Kembali</th>
              <th>Assesment</th>
              <th>Kronologi</th>
              <th>Permintaan Litmas</th>
              <th>Interview Bapas</th>
              <th>Litmas Datang</th>
              <th>Action</th>
            <?php echo $__env->renderComponent(); ?>
          </div>
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- DataTables -->
<script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
<!-- page script -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/daeng_agiel/Development/Laravel/lapas/resources/views/surat/index.blade.php ENDPATH**/ ?>