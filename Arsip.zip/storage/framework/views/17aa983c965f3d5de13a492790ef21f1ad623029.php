<div class="card">
    <div class="card-header">
        <h3 class="card-title"><?php echo e($title); ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <table id="<?php echo e($id); ?>" class="table table-bordered">
            <thead>
            <tr>
                <?php echo e($slot); ?>

            </tr>
            </thead>
        </table>
    </div>
    <!-- /.card-body -->
</div><?php /**PATH /Users/daeng_agiel/Development/Laravel/admin_slq/resources/views/components/table.blade.php ENDPATH**/ ?>