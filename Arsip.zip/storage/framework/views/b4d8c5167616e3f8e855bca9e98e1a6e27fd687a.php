<div class="card">
    <div class="card-header">
        <h3 class="card-title"><?php echo e($title); ?></h3>
            <div class="card-tools">
                <a href="<?php echo e(route('binaan.create')); ?>" class="btn btn-sm btn-success"><span class="fa fa-plus"></span> Binaan Baru</a>
            </div>

    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <table id="<?php echo e($id); ?>" class="table table-striped table-bordered">
            <thead>
            <tr>
                <?php echo e($slot); ?>

            </tr>
            </thead>
        </table>
    </div>
    <!-- /.card-body -->
</div><?php /**PATH /Users/daeng_agiel/Development/Laravel/lapas/resources/views/components/table.blade.php ENDPATH**/ ?>