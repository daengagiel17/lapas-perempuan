<?php $__env->startSection('css'); ?>
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <?php $__env->startComponent('components.wrapper', ['title' => "Surat"]); ?>
      <li class="breadcrumb-item active">Surat</li>
    <?php echo $__env->renderComponent(); ?>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          
          <div class="col-12">
            <?php $__env->startComponent('components.table', ['id' => 'data-binaan']); ?>
              <?php $__env->slot('title'); ?>
                List of Surat
              <?php $__env->endSlot(); ?>
              <th>#</th>
              <th>No Register</th>
              <th>Nama</th>
              <th>Ke RT/RW</th>
              <th>Dari RT/RW</th>
              <th>Assesment</th>
              <th>Kronologi</th>
              <th>Ke Litmas</th>
              <th>Interview</th>
              <th>Dari Litmas</th>
              <th>Action</th>
            <?php echo $__env->renderComponent(); ?>
          </div>
        </div><!-- /.row -->
        <?php $__env->startComponent('components.modal'); ?>
        <?php echo $__env->renderComponent(); ?>
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- DataTables -->
<script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
<!-- page script -->
<script type="text/javascript" language="javascript">
  $(function (){
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
    });

    load_data();

    function load_data(fakultas = '', jurusan = '', kelas = '')
    {
      $("#data-binaan").DataTable({
        // "processing": true,
        "serverSide": true,
        "ajax": {
          url : "<?php echo e(route('binaan.index')); ?>",
          data : {
            fakultas: fakultas,
            jurusan: jurusan,
            kelas: kelas
          }
        },
        "columns": [
          {
            data: 'DT_RowIndex',
            name: 'id'
          },
          {
            data: "no_register" ,
            name: "no_register"
          },
          {
            data: "nama",
            name: "nama"
          },
          {
            data: "surat_rt_dibuat",
            name: "surat_rt_dibuat"
          },
          {
            data: "surat_rt_kembali",
            name: "surat_rt_kembali"
          },
          {
            data: "assesment",
            name: "assesment"
          },
          {
            data: "kronologi",
            name: "kronologi"
          },
          {
            data: "permintaan_litmas",
            name: "permintaan_litmas"
          },
          {
            data: "interview_bapas",
            name: "interview_bapas"
          },
          {
            data: "litmas_datang",
            name: "litmas_datang"
          },
          {
            data: "action",
            name: "action"
          }
        ],
      });
    }

    $('body').on('click', '.update-proses', function () {
      if($(this).data('id-proses')==6)
      {
        $('#binaan_id_petugas').val($(this).data('id'));
        $('#proses_id_petugas').val($(this).data('id-proses'));
        $('#modal-input-petugas').modal('show');
      }
      else
      {
        $('#binaan_id').val($(this).data('id'));
        $('#proses_id').val($(this).data('id-proses'));
        $('#modal-input').modal('show');
      }
   });

    $('#save-button').click(function (e) {
        e.preventDefault();
        $(this).html('Sending..');
        // console.log($('#proses-form').serialize());
        $.ajax({  
          data: $('#proses-form').serialize(),
          url: "<?php echo e(route('binaan.update-proses')); ?>",
          type: "POST",
          dataType: 'json',
          success: function (data) {
            console.log(data);
              $('#progres-form').trigger("reset");
              $('#modal-input').modal('hide');
              window.location = "<?php echo e(route('binaan.index')); ?>";
          },
          error: function (data) {
              console.log('Error:', data);
              $('#save-button').html('Simpan');
          }
      });
    });  

    $('#save-button-petugas').click(function (e) {
        e.preventDefault();
        $(this).html('Sending..');
        console.log($('#proses-form-petugas').serialize());
        $.ajax({  
          data: $('#proses-form-petugas').serialize(),
          url: "<?php echo e(route('binaan.update-proses-petugas')); ?>",
          type: "POST",
          dataType: 'json',
          success: function (data) {
            console.log(data);
              $('#progres-form-petugas').trigger("reset");
              $('#modal-input-petugas').modal('hide');
              window.location = "<?php echo e(route('binaan.index')); ?>";
          },

          error: function (data) {
              console.log('Error:', data);
              $('#save-button-petugas').html('Simpan');
          }
      });
    });  

    // $('#filter').click(function() {
    //   var fakultas = $('#fakultas').val();
    //   var jurusan = $('#jurusan').val();
    //   var kelas = $('#kelas').val();

    //   $('#data-mahasiswa').DataTable().destroy();
    //   load_data(fakultas, jurusan, kelas);
    // });
    
    // $('#reset-filter').click(function() {
    //   $('#fakultas').empty();
    //   $('#fakultas').append("<option value=''>Select Fakultas</option>");

    //   var fakultas = <?php echo json_encode($fakultas); ?>;
      
    //   for (i = 0; i < fakultas.length; i++)
    //   {
    //       $('#fakultas').append("<option value='" + fakultas[i].id + "'>" + fakultas[i].slug + "</option>");
    //   }

    //   $('#jurusan').empty();       
    //   $('#jurusan').append("<option value=''>Select Jurusan</option>");
    //   $('#kelas').empty();       
    //   $('#kelas').append("<option value=''>Select Kelas</option>");
    
    //   $('#data-mahasiswa').DataTable().destroy();
    //   load_data();

    // });


    // // When an option is changed, search the above for matching choices
    // $('#fakultas').on('change', function() {
    //   // Set selected option as variable
    //   var fakultas_id = $(this).val();

    //   if(fakultas_id)
    //   {
    //     // Empty the target field
    //     $('#jurusan').empty();
    //     $('#jurusan').append("<option value=''>Select Jurusan</option>");
    //     $('#kelas').empty();        
    //     $('#kelas').append("<option value=''>Select Kelas</option>");

    //     var jurusan = <?php echo json_encode($jurusans); ?>;
    //     // For each chocie in the selected option
    //     for (i = 0; i < jurusan[fakultas_id].length; i++)
    //     {
    //         $('#jurusan').append("<option value='" + jurusan[fakultas_id][i].id + "'>" + jurusan[fakultas_id][i].slug + "</option>");
    //     }

    //   }
    //   else
    //   {
    //     $('#jurusan').empty();        
    //     $('#jurusan').append("<option value=''>Select Jurusan</option>");
    //     $('#kelas').empty();        
    //     $('#kelas').append("<option value=''>Select Kelas</option>");
    //   }      
    // });    

    // // When an option is changed, search the above for matching choices
    // $('#jurusan').on('change', function() {
    //   // Set selected option as variable
    //   var jurusans_id = $(this).val();

    //   if(jurusans_id)
    //   {
    //     // Empty the target field
    //     $('#kelas').empty();       
    //     $('#kelas').append("<option value=''>Select Kelas</option>");

    //     var kelas = <?php echo json_encode($kelas); ?>;
    //     // For each chocie in the selected option
    //     for (i = 0; i < kelas[jurusans_id].length; i++)
    //     {
    //         $('#kelas').append("<option value='" + kelas[jurusans_id][i].id + "'>" + kelas[jurusans_id][i].name + "</option>");
    //     }

    //   }
    //   else
    //   {
    //     $('#kelas').empty();        
    //     $('#kelas').append("<option value=''>Select Kelas</option>");
    //   }      
    // });    

  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/daeng_agiel/Development/Laravel/lapas/resources/views/binaan/index.blade.php ENDPATH**/ ?>