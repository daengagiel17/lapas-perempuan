<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Post</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Post</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">List of Post</h3>
                <div class="card-tools">
                  <a href="<?php echo e(route('post.create')); ?>" class="btn btn-sm btn-success"><i class="fas fa-plus"></i> Create</a>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover">
                  <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Action</th>
                  </tr>
                  <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($post->id); ?></td>
                      <td><?php echo e($post->title); ?></td>
                      <td><?php echo e($post->description); ?></td>
                      <td>
                        <a href="<?php echo e(route('post.show', ['id' => $post->id])); ?>" class="btn btn-sm btn-info"><i class="fas fa-eye"></i></a>
                        <a href="<?php echo e(route('post.edit', ['id' => $post->id])); ?>" class="btn btn-sm btn-primary"><i class="fas fa-edit"></i></a>
                        <a class="btn btn-sm btn-danger" href="<?php echo e(route('post.destroy', ['id' => $post->id])); ?>"
                            onclick="event.preventDefault();
                                          document.getElementById('destroy-form-<?php echo e($post->id); ?>').submit();">
                            <i class="fas fa-trash"></i>
                        </a>
                        <form id="destroy-form-<?php echo e($post->id); ?>" action="<?php echo e(route('post.destroy', ['id' => $post->id])); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        </form>
                      </td>
                    </tr>                      
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/daeng_agiel/Development/Laravel/admin-laravel/resources/views/post/index.blade.php ENDPATH**/ ?>