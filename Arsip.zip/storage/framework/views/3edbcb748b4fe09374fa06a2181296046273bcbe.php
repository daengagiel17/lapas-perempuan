<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Warga Binaan</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Warga Binaan</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <!-- Widget: user widget style 2 -->
            <div class="card card-widget widget-user-2">
              <!-- Add the bg color to the header using any of the bg-* classes -->
              <div class="widget-user-header bg-primary">
                <div class="widget-user-image">
                  <img class="img-circle elevation-2" src="<?php echo e(asset('img/profile/default.png')); ?>" alt="Warga Binaan">
                </div>
                <!-- /.widget-user-image -->
                <h3 class="widget-user-username"><?php echo e($binaan->nama); ?></h3>
                <h5 class="widget-user-desc"><?php echo e($binaan->no_register); ?></h5>
              </div>
              <div class="card-footer p-0">
                <ul class="nav flex-column">
                  <li class="nav-item">
                    <label class="nav-link">Petugas Interview <span class="float-right badge bg-primary"><?php echo e($binaan->petugasInterview?Str::upper($binaan->petugasInterview->nama_petugas):'Belum ada data'); ?></span></label>
                  </li>
                  <li class="nav-item">
                    <label class="nav-link">Asal Bapas Petugas <span class="float-right badge bg-primary"><?php echo e($binaan->petugasInterview?Str::upper($binaan->petugasInterview->asal_petugas):'Belum ada data'); ?></span></label>
                  </li>
                  <li class="nav-item">
                    <label class="nav-link">Pidana <span class="float-right badge bg-warning"><?php echo e($binaan->pidana??'Belum ada data'); ?></span></label>
                  </li>
                  <li class="nav-item">
                    <label class="nav-link">Expirasi <span class="float-right badge bg-success"><?php echo e($binaan->expirasi??'Belum ada data'); ?></span></label>
                  </li>
                  <li class="nav-item">
                    <label class="nav-link">1/2 MP <span class="float-right badge bg-info"><?php echo e($binaan->seperdua_mp??'Belum ada data'); ?></span></label>
                  </li>
                  <li class="nav-item">
                    <label class="nav-link">2/3 MP <span class="float-right badge bg-danger"><?php echo e($binaan->duapertiga_mp??'Belum ada data'); ?></span></label>
                  </li>
                </ul>
              </div>
              <div class="card-footer">
                <div class="row">
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('super admin')): ?>
                    <div class="col-md-4">
                      <a href="<?php echo e(route('binaan.edit', ['id' => $binaan->id])); ?>" class="btn btn-sm btn-block btn-info"><i class="fa fa-edit"></i> Edit</a>
                    </div>
                    <div class="col-md-4">
                      <a class="btn btn-sm btn-danger btn-block" href="<?php echo e(route('binaan.destroy', ['id' => $binaan->id])); ?>"
                          onclick="event.preventDefault();
                                        document.getElementById('destroy-form').submit();">
                          <i class="fas fa-trash"></i>
                          Hapus
                      </a>
                      <form id="destroy-form" action="<?php echo e(route('binaan.destroy', ['id' => $binaan->id])); ?>" method="POST" style="display: none;">
                          <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                      </form>
                    </div>                    
                    <div class="col-md-4">
                      <a href="<?php echo e(route('binaan.index')); ?>" class="btn btn-sm btn-block btn-primary"><i class="fa fa-arrow-left"></i> Back</a>
                    </div>

                  <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                    <div class="col-md-6">
                      <a href="<?php echo e(route('binaan.edit', ['id' => $binaan->id])); ?>" class="btn btn-sm btn-block btn-primary"><i class="fa fa-edit"></i> Edit</a>
                    </div>
                    <div class="col-md-6">
                      <a href="<?php echo e(route('binaan.show')); ?>" class="btn btn-sm btn-block btn-danger"><i class="fa fa-arrow-left"></i> Back</a>
                    </div>
                  <?php endif; ?>
                </div>
              </div>
            </div>
            <!-- /.widget-user -->
          </div>
          <div class="col-md-8">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Detail Proses</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover">
                  <tr>
                    <th>Admin</th>
                    <th>Aktifitas</th>
                    <th>Waktu</th>
                  </tr>
                  <?php $__currentLoopData = $prosess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($proses->name_user); ?></td>
                      <td>Input tanggal <strong><?php echo e($proses->tanggal); ?></strong> pada <?php echo e($proses->name_proses); ?></td>
                      <td><?php echo e(isset($proses->updated_at)?\Carbon\Carbon::parse($proses->updated_at)->diffForHumans():'-'); ?></td>
                    </tr>                      
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/daeng_agiel/Development/Laravel/lapas/resources/views/binaan/show.blade.php ENDPATH**/ ?>