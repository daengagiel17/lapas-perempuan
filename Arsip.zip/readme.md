<h1 align="center">Admin SLQ</h1>

## About

SLQ merupakan aplikasi website untuk admin. Merupakan bagian dari sistem informasi manajemen semarak literasi al-quran yang merupakan program Markaz Dakwah wa Khidmatul Mujtama (MDKM) dalam menggalakkan dakwah Islam. Sistem ini berfungsi untuk mempermudah pengelolaan Kegiatan Belajar Mengajar (KBM). Untuk Admin SLQ ini sendiri memiliki fitur utama sebagai berikut:
- Kelola status mahasiswa.
- Kelola data instruktur.
- Pembagian Kelompok.
- Publish nilai.
- Printout hasil presensi, penilaian.
- Statistik Pembelajaran

## Developer

Aplikasi ini dikembangkan oleh [IRIT.IO] (https://irit-io.id/) Software Developer. Anda dapat menghubungi kami via Whatsapp 081935911244 atau kunjungi IG kami [@irit.io] (https://www.instagram.com/irit.io/)
